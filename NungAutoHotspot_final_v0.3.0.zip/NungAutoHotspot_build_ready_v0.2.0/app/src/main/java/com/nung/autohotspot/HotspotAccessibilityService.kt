package com.nung.autohotspot

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class HotspotAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile private var instance: HotspotAccessibilityService? = null
        private var pending: Boolean? = null
        fun requestHotspotAction(context: Context, enabled: Boolean) {
            pending = enabled
            val s = instance
            if (s != null) s.openAndTry(enabled) else {
                val i = Intent(Settings.ACTION_TETHER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
            }
        }
    }

    override fun onServiceConnected() { instance = this; super.onServiceConnected(); pending?.let { openAndTry(it) } }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { pending?.let { tryClickHotspot(it) } }
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    private fun openAndTry(enabled: Boolean) {
        pending = enabled
        startActivity(Intent(Settings.ACTION_TETHER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun tryClickHotspot(enabled: Boolean) {
        val root = rootInActiveWindow ?: return
        val candidates = listOf("ฮอตสปอตพกพา", "ฮอตสปอต", "Portable hotspot", "Hotspot")
        val node = candidates.asSequence().mapNotNull { root.findAccessibilityNodeInfosByText(it).firstOrNull() }.firstOrNull() ?: return
        val clickable = if (node.isClickable) node else findClickableParent(node)
        if (clickable != null) {
            val checked = clickable.isChecked
            if (checked != enabled) clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            pending = null
        }
    }

    private fun findClickableParent(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var p = node.parent
        repeat(6) {
            if (p?.isClickable == true) return p
            p = p?.parent
        }
        return null
    }
}
