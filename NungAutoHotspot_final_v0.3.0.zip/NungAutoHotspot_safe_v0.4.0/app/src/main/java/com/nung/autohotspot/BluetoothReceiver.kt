package com.nung.autohotspot

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class BluetoothReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val device = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        }

        val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val selected = prefs.getString("device_address", null)
        if (device?.address != selected) return

        val connected = intent.action == BluetoothDevice.ACTION_ACL_CONNECTED
        prefs.edit().putBoolean("car_connected", connected).apply()

        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        val channelId = "hotspot"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Nung Auto Hotspot", NotificationManager.IMPORTANCE_HIGH)
            )
        }

        val settingsIntent = Intent(Settings.ACTION_TETHER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            context, 100, settingsIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val title = if (connected) "BYD เชื่อมต่อแล้ว" else "BYD ตัดการเชื่อมต่อแล้ว"
        val text = if (connected) {
            "แตะเพื่อเปิดหน้าตั้งค่า Hotspot แล้วเปิด Hotspot"
        } else {
            "แตะเพื่อเปิดหน้าตั้งค่า Hotspot แล้วปิด Hotspot หากต้องการ"
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_wifi)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        NotificationManagerCompat.from(context).notify(if (connected) 1001 else 1002, notification)
    }
}
