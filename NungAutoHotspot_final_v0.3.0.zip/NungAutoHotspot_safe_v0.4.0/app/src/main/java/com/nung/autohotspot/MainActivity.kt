package com.nung.autohotspot

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (android.os.Build.VERSION.SDK_INT >= 31 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 10)
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }

        status = TextView(this).apply { textSize = 18f }
        root.addView(TextView(this).apply {
            text = "Nung Auto Hotspot\n\nตรวจจับ Bluetooth ของรถ BYD และแจ้งเตือนเมื่อรถเชื่อมต่อหรือยกเลิกการเชื่อมต่อ"
            textSize = 22f
        })
        root.addView(status)

        root.addView(Button(this).apply {
            text = "เลือกอุปกรณ์ Bluetooth"
            setOnClickListener { chooseDevice() }
        })

        root.addView(Button(this).apply {
            text = "เปิดหน้าตั้งค่า Hotspot"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_TETHER_SETTINGS))
            }
        })

        setContentView(root)
        refresh()
    }

    private fun chooseDevice() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        val paired = adapter.bondedDevices.toList().sortedBy { it.name ?: it.address }
        val names = paired.map { "${it.name ?: "ไม่ทราบชื่อ"}\n${it.address}" }.toTypedArray()
        if (names.isEmpty()) return
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("เลือก Bluetooth ของรถ")
            .setItems(names) { _, which ->
                prefs.edit().putString("device_address", paired[which].address).apply()
                refresh()
            }.show()
    }

    private fun refresh() {
        val addr = prefs.getString("device_address", null)
        status.text = if (addr == null) {
            "ยังไม่ได้เลือกรถ"
        } else {
            "รถที่เลือก: $addr\n\nเมื่อ Bluetooth รถเชื่อมต่อ แอปจะแจ้งเตือนให้เปิด Hotspot\nเมื่อรถตัดการเชื่อมต่อ แอปจะแจ้งเตือนให้ปิด Hotspot"
        }
    }
}
