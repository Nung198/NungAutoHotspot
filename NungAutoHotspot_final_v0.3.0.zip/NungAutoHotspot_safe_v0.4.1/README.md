# Nung Auto Hotspot v0.4.1 SAFE

A privacy-focused BYD Bluetooth helper for Android.

## Safe design
This version does not use AccessibilityService and does not read screen content.

When the selected BYD Bluetooth device connects/disconnects, the app sends a notification.
Tapping the notification opens Android's Hotspot settings so the user can switch Hotspot on/off.

Android does not allow ordinary third-party apps to silently toggle internet tethering on modern
devices without privileged/system access. Therefore this version deliberately uses a user action
instead of Accessibility automation.

Application ID: `com.nung.autohotspot`
