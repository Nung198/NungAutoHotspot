package com.nung.autohotspot

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 31 && ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 10)
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48,48,48,48) }
        status = TextView(this).apply { textSize = 18f }
        root.addView(TextView(this).apply { text = "Nung Auto Hotspot\n\nเลือก Bluetooth ของรถ BYD ที่จับคู่ไว้ แล้วเปิดบริการอัตโนมัติ"; textSize = 22f })
        root.addView(status)
        val select = Button(this).apply { text = "เลือกอุปกรณ์ Bluetooth"; setOnClickListener { chooseDevice() } }
        root.addView(select)
        root.addView(Button(this).apply { text = "เปิดสิทธิ์ Accessibility (ใช้เฉพาะถ้าต้องการเปิด/ปิด Hotspot อัตโนมัติ)"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(Button(this).apply { text = "เปิดหน้าตั้งค่า Hotspot"; setOnClickListener { startActivity(Intent("android.settings.TETHER_SETTINGS")) } })
        setContentView(root)
        refresh()
    }

    private fun chooseDevice() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        val paired = adapter.bondedDevices.toList().sortedBy { it.name ?: it.address }
        val names = paired.map { "${it.name ?: "ไม่ทราบชื่อ"}\n${it.address}" }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("เลือก Bluetooth ของรถ")
            .setItems(names) { _, which ->
                val d = paired[which]
                prefs.edit().putString("device_address", d.address).apply()
                refresh()
            }.show()
    }

    private fun refresh() {
        val addr = prefs.getString("device_address", null)
        status.text = if (addr == null) "ยังไม่ได้เลือกรถ" else "รถที่เลือก: $addr\n\nเมื่อ Bluetooth รถเชื่อมต่อ แอปจะพยายามสั่ง Hotspot ผ่าน Accessibility; เมื่อรถตัดการเชื่อมต่อจะสั่งปิด"
    }
}
