package com.nung.autohotspot

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast

class BluetoothReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val device = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        val selected = context.getSharedPreferences("settings", Context.MODE_PRIVATE).getString("device_address", null)
        if (device?.address != selected) return
        val connected = intent.action == BluetoothDevice.ACTION_ACL_CONNECTED
        context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putBoolean("car_connected", connected).apply()
        Toast.makeText(context, if (connected) "BYD เชื่อมต่อแล้ว — กำลังเปิด Hotspot" else "BYD ตัดการเชื่อมต่อ — กำลังปิด Hotspot", Toast.LENGTH_SHORT).show()
        HotspotAccessibilityService.requestHotspotAction(context, connected)
    }
}
