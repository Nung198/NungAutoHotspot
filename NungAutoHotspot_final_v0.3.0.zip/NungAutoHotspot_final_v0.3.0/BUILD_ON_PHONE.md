# วิธี Build APK จากมือถือ (ไม่ต้องมีคอม)

โปรเจกต์นี้เตรียม GitHub Actions ไว้ให้แล้ว จึงไม่ต้องติดตั้ง Android Studio บนมือถือ

1. สร้าง GitHub repository ใหม่ 1 อัน (แนะนำตั้งเป็น Private)
2. แตก ZIP นี้ แล้วอัปโหลดไฟล์/โฟลเดอร์ทั้งหมดเข้า repository โดยให้ไฟล์ `.github/workflows/build-apk.yml` อยู่ในตำแหน่งเดิม
3. เปิดแท็บ **Actions** ของ repository
4. เลือก **Build Nung Auto Hotspot APK**
5. กด **Run workflow**
6. รอจนขึ้นสถานะสำเร็จ
7. เข้า run ที่สำเร็จ แล้วเลื่อนลงส่วน **Artifacts**
8. ดาวน์โหลด `NungAutoHotspot-debug-apk.zip`
9. แตกไฟล์ จะได้ `app-debug.apk`
10. เปิด APK บนโทรศัพท์เพื่อติดตั้ง

หมายเหตุ: APK นี้เป็น debug APK สำหรับทดสอบส่วนตัว ไม่ใช่ release APK สำหรับเผยแพร่บน Play Store
