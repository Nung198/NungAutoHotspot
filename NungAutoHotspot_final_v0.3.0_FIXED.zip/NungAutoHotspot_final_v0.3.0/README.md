# Nung Auto Hotspot v0.2.0

ต้นแบบแอปส่วนตัวสำหรับ Android/HyperOS เพื่อผูก Bluetooth ของรถ BYD กับการเปิด/ปิด Portable Hotspot โดยใช้ Accessibility Service เป็นกลไกสำรอง เนื่องจากแอปทั่วไปไม่สามารถสั่ง Tethering โดยตรงได้ในหลายกรณีของ Android รุ่นใหม่

## สิทธิ์ที่ใช้
- **Bluetooth Connect** — ใช้ดูอุปกรณ์ Bluetooth ที่จับคู่และตรวจสอบเหตุการณ์เชื่อมต่อ/ตัดการเชื่อมต่อ
- **Accessibility Service** — ใช้เฉพาะเมื่อผู้ใช้เปิดสิทธิ์เอง เพื่อเปิดหน้าตั้งค่า Tethering และกดสวิตช์ Hotspot ตามสถานะ Bluetooth ของรถ

ไม่มีโฆษณา ไม่มีบัญชี ไม่มีเซิร์ฟเวอร์ และไม่มีการส่งข้อมูลไปยังบริการภายนอกโดยตัวแอป

## Build
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Kotlin 2.0.21
- compileSdk/targetSdk 35
- minSdk 29

ดูขั้นตอนสำหรับ Build จากมือถือที่ `BUILD_ON_PHONE.md`

## ข้อจำกัด
ชื่อข้อความของสวิตช์ Hotspot ในหน้า Settings อาจแตกต่างกันตามรุ่น HyperOS/ภาษาเครื่อง หากไม่ตรงกับข้อความที่แอปค้นหา อาจต้องปรับตัวค้นหาใน `HotspotAccessibilityService.kt`
